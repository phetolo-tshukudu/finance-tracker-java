package Model;

public enum Category {
	FOOD,
    TRANSPORT,
    RENT,
    UTILITIES,
    ENTERTAINMENT,
    SALARY,
    OTHER
}
